To run put make sure file pg20776.txt is in the same directory as the src folder. Run the program p2 in the src folder to compress the file.
The compressed file will be placed in the same directory as the original file.

Original File = 38KB
Compressed Binary File = 28KB
Space saving: 27%

Huffman.txt contains the compressedString that is written to the binary file.